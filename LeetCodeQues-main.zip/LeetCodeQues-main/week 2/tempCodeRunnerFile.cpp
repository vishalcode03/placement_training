 // for(int n  : arr){
    //     count[n]++;
    // }